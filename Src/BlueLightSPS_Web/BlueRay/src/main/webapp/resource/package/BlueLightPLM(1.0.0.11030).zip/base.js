﻿/// <reference path="jqgrid/jqassist.ts" />
/// <reference path="util.ts" />

var base;
(function (base) {
    var JQGridAssistantFactory = (function () {
        function JQGridAssistantFactory() {
        }
        JQGridAssistantFactory.createTable = function (gridName, cols, widths) {
            var nodes = [];
            for (var i = 0; i < cols.length; ++i) {
                nodes.push(new JQTable.Node(cols[i], gridName + "_col_" + i, true, true, widths[i]));
            }
            return new JQTable.JQGridAssistant(nodes, gridName);
        };
        return JQGridAssistantFactory;
    })();

    var GridView = (function () {
        function GridView(tableId, cols, widths) {
            this.rowNum = mediator.onGetRowNum();
            this.mInit = false;
            this.mDisabledRows = [];
            this.mIsShowHideTriggered = false;
            this.mCols = cols;
            grids[tableId] = this;
            this.mTableName = tableId;
            this.mTable = $('#' + tableId);
            this.updateTable(tableId, widths);
        }
        GridView.prototype.getRowNum = function () {
            return this.rowNum;
        };

        GridView.prototype.getCurPage = function () {
            return this.curPage;
        };

        GridView.prototype.getTableName = function () {
            return this.mTableName;
        };

        GridView.prototype.isSelected = function (rowId) {
            var rows = this.getSelectedRowData();
            for (var i = 0; i < rows.length; ++i) {
                if (rows[i] == rowId) {
                    return true;
                }
            }
            return false;
        };

        GridView.prototype.isDisabled = function (rowId) {
            for (var i = 0; i < this.mDisabledRows.length; ++i) {
                if (this.mDisabledRows[i] == rowId) {
                    return true;
                }
            }
            return false;
        };

        GridView.prototype.disableSelect = function (rowId) {
            if (this.isSelected(rowId)) {
                this.mTable.jqGrid('setSelection', rowId, false);
            }
            if (!this.isDisabled(rowId)) {
                var checkBox = $("#" + this.mTableName + " #jqg_" + this.mTableName + "_" + rowId);
                if (checkBox.length > 0) {
                    checkBox[0].disabled = true;
                }
                this.mDisabledRows.push(rowId);
            }
        };

        GridView.prototype.enableSelect = function (rowId) {
            for (var i = 0; i < this.mDisabledRows.length; ++i) {
                if (this.mDisabledRows[i] == rowId) {
                    var tmp = this.mDisabledRows[this.mDisabledRows.length - 1];
                    this.mDisabledRows[i] = tmp;
                    this.mDisabledRows.pop();
                    var checkBox = $("#" + this.mTableName + " #jqg_" + this.mTableName + "_" + rowId);
                    if (checkBox.length > 0) {
                        checkBox[0].disabled = false;
                    }
                    break;
                }
            }
        };

        GridView.prototype.getDisabledRows = function () {
            return this.mDisabledRows;
        };

        GridView.prototype.showHideRow = function (rowId, show) {
            if (show) {
                $("#" + this.mTableName + "p #" + rowId).css("display", "");
            } else {
                $("#" + this.mTableName + "p #" + rowId).css("display", "none");
            }
        };

        GridView.prototype.setCellColor = function (rowId, colId, r, g, b) {
            $("#" + this.mTableName + " #" + rowId + " #" + colId + rowId).css("background", "rgb(" + r + "," + g + "," + b + ")");
        };

        GridView.prototype.setRowBgColor = function (row, r, g, b) {
            $("#" + this.mTableName + " #" + row).css("background", "rgb(" + r + "," + g + "," + b + ")");
        };

        GridView.prototype.setRowFgColor = function (row, r, g, b) {
            $("#" + this.mTableName + " #" + row).css("color", "rgb(" + r + "," + g + "," + b + ")");
        };

        GridView.prototype.getRowId = function (row) {
            var ids = this.mTable.jqGrid('getDataIDs');
            if (ids.length <= row) {
                return -1;
            }
            return parseInt(ids[row]);
        };

        GridView.prototype.addRowData = function (rdata) {
            var ids = this.mTable.jqGrid('getDataIDs');
            var rowid = 0;
            if (ids != "") {
                rowid = parseInt(Math.max.apply(Math, ids)) + 1;
            }
            this.mTable.jqGrid('addRowData', rowid, rdata, 'last');
            return rowid;
        };

        GridView.prototype.addRowDataById = function (id, rdata) {
            this.mTable.jqGrid('addRowData', id, rdata, 'last');
        };

        GridView.prototype.delRowData = function (rowId) {
            if (this.isSelected(rowId)) {
                this.mTable.jqGrid('setSelection', rowId, false);
            }
            this.mTable.jqGrid('delRowData', rowId);
        };

        GridView.prototype.setSelect = function (rowId, sel) {
            this.mTable.jqGrid('setSelection', rowId, sel);
        };

        GridView.prototype.cleanSelectedRow = function () {
            var rowIds = [].concat(this.getSelectedRowData());
            if (null != rowIds) {
                for (var id in rowIds) {
                    this.mTable.jqGrid('setSelection', rowIds[id], false);
                }
            }
        };

        GridView.prototype.getRowData = function (rowId) {
            return this.mTable.jqGrid('getRowData', rowId);
        };

        GridView.prototype.getSelectedRowData = function () {
            return this.mTable.jqGrid('getGridParam', 'selarrrow');
        };

        GridView.prototype.getRowCount = function () {
            return this.mTable.jqGrid("getRowData").length;
        };

        GridView.prototype.setCellData = function (rowId, colId, data) {
            this.mTable.jqGrid('setCell', rowId, colId, data, undefined, undefined, true);
        };

        GridView.prototype.reload = function () {
            this.mTable.trigger("reloadGrid");
        };

        GridView.prototype.showHideCol = function (colId, show) {
            this.mIsShowHideTriggered = true;
            if (show) {
                $("#" + this.mTableName).setGridParam().showCol(colId);
            } else {
                $("#" + this.mTableName).setGridParam().hideCol(colId);
            }
            this.mIsShowHideTriggered = false;
        };

        GridView.prototype.setCheckedCount = function (count) {
            var countDiv = $("#" + this.mTableName + "pager #checked_count_blueray");
            if (countDiv.length == 0) {
                $("#" + this.mTableName + "pager #" + this.mTableName + "pager_left table tr").prepend('<td><div id="checked_count_blueray"></div></td><td><div style="width:5px"</div></td>');
                countDiv = $("#" + this.mTableName + "pager #checked_count_blueray");
            }
            countDiv.text(count + "个被选中 ");
        };

        GridView.prototype.updateTable = function (name, widths) {
            var _this = this;
            var tableAssist = JQGridAssistantFactory.createTable(name, this.mCols, widths);
            var data = [];

            this.mTable.jqGrid(tableAssist.decorate({
                // url: "TestTable/WGDD_load.do",
                // datatype: "json",
                //data: tableAssist.getData(data),
                // datatype: "json",
                datatype: function (postdata) {
                    try  {
                        _this.rowNum = postdata.rows;
                        _this.curPage = postdata.page;
                        if (!_this.mInit) {
                            _this.mInit = true;
                            _this.cleanSelectedRow();
                            mediator.onGridComplete(_this.mTableName);
                        } else if (!_this.mIsShowHideTriggered) {
                            var index = -1;
                            if ("" != postdata.sidx) {
                                $("#" + postdata.sidx + " .s-ico").show();
                                index = parseInt(postdata.sidx.replace(name + "_col_", ""));
                            }

                            //alert("onupdate");
                            _this.cleanSelectedRow();

                            mediator.onUpdate(_this.mTableName, postdata.page, postdata.rows, index, ("asc" == postdata.sord));
                        }
                    } catch (e) {
                    }
                },
                //onPaging: (v1, v2, v3) => {
                //    var k = 0;
                //},
                multiselect: true,
                //multikey: "ctrlKey",
                //drag: false,
                // resize: false,
                // autowidth : true,
                //cellsubmit: 'clientArray',
                // cellEdit: false,
                //viewrecords: true,
                sortorder: "desc",
                height: document.documentElement.clientHeight - 22 - 3 - 27,
                width: document.documentElement.clientWidth - 3,
                shrinkToFit: false,
                rowNum: this.rowNum,
                //rowList: [5, 10, 15],
                autoScroll: true,
                viewrecords: true,
                pager: name + 'pager',
                beforeSelectRow: function (rowId) {
                    return !_this.isDisabled(rowId);
                },
                onSelectRow: function (a, b, c) {
                    mediator.onRowChecked(_this.mTableName);
                    _this.setCheckedCount(_this.getSelectedRowData().length);
                },
                onSelectAll: function (a, b, c) {
                    mediator.onRowChecked(_this.mTableName);
                    _this.setCheckedCount(_this.getSelectedRowData().length);
                },
                gridComplete: function () {
                    _this.setCheckedCount(_this.getSelectedRowData().length);
                }
            }));
            var exporteId = name + "_export";
            this.mTable.jqGrid('navGrid', "#" + name + 'pager', { search: false, refresh: false, edit: false, add: false, del: false }).jqGrid('navButtonAdd', "#" + name + 'pager', {
                caption: "", buttonicon: "none", onClickButton: function () {
                    mediator.onExportClicked(_this.mTableName);
                }, position: "last", title: "按表格导出数据", id: exporteId
            });
            this.reload();

            $("#" + exporteId + " div").addClass("ui-icon");
            $("#" + exporteId + " div").addClass("ui-icon-circle-arrow-s");
            $("#" + name + "pager_left").css("padding-top", "3px");
            //.navGrid('#pager', { search: false, reloadGrid: false, edit: false, add: false, del: false });
        };
        return GridView;
    })();
    base.GridView = GridView;
})(base || (base = {}));
//# sourceMappingURL=base.js.map
